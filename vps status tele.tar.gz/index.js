import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';
import os from 'os';
import osu from 'os-utils';
import fs from 'fs-extra';
import path from 'path';

dotenv.config();

const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });
const imageFolder = './image_db';
const logFile = './vps_log.txt';

function getVPSStatus() {
  return new Promise((resolve) => {
    osu.cpuUsage((cpuPercent) => {
      const totalMem = os.totalmem() / (1024 ** 3);
      const freeMem = os.freemem() / (1024 ** 3);
      const usedMemPercent = ((totalMem - freeMem) / totalMem * 100).toFixed(2);
      const uptime = os.uptime() / 60; // dalam menit

      const status = 
        `🖥️ CPU Usage: ${(cpuPercent * 100).toFixed(2)}%\n` +
        `💾 RAM Usage: ${usedMemPercent}%\n` +
        `⏱️ Uptime: ${uptime.toFixed(2)} menit`;

      // Log ke file
      const timestamp = new Date().toISOString();
      fs.appendFileSync(logFile, `[${timestamp}]\n${status}\n\n`);

      resolve(status);
    });
  });
}

function getRandomImagePath() {
  const files = fs.readdirSync(imageFolder).filter(f => /\.(jpg|jpeg|png)$/i.test(f));
  if (files.length === 0) return null;
  return path.join(imageFolder, files[Math.floor(Math.random() * files.length)]);
}

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const opts = {
    reply_markup: {
      inline_keyboard: [
        [{ text: '📊 Cek VPS', callback_data: 'cek_vps' }],
      ]
    }
  };
  bot.sendMessage(chatId, 'Selamat datang di rikka bot:', opts);
});

bot.on('callback_query', async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;

  if (data === 'cek_vps') {
    const status = await getVPSStatus();
    const imagePath = getRandomImagePath();
    if (imagePath) {
      await bot.sendPhoto(chatId, imagePath, { caption: `📡 Status VPS:\n${status}` });
    } else {
      await bot.sendMessage(chatId, `📡 Status VPS:\n${status}`);
    }
  } else if (data === 'kirim_gambar') {
    const imagePath = getRandomImagePath();
    if (imagePath) {
      await bot.sendPhoto(chatId, imagePath);
    } else {
      await bot.sendMessage(chatId, '❌ Tidak ada gambar di folder image_db.');
    }
  }

  bot.answerCallbackQuery(callbackQuery.id);
});
